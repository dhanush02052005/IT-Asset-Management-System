package com.jfs.training;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.jfs.training.bean.AssetItemBean;
import com.jfs.training.service.AssetItemService;

@SpringBootTest
public class AssetItemServiceTest {

    @Autowired
    private AssetItemService assetItemService;

    @Test
    public void testAddAssetItem() {

        // ToDo Test Case 1
        // Verify asset item can be added successfully
        // using service layer
        AssetItemBean assetItemBean = new AssetItemBean();
        assetItemBean.setAssetCode("AST-101");
        assetItemBean.setAssetName("Dell Latitude Laptop");
        assetItemBean.setCategory("Hardware");
        assetItemBean.setAssignedTo("Alex Morgan");
        assetItemBean.setStatus("Allocated");

        AssetItemBean savedAsset = assetItemService.addAssetItem(assetItemBean);
        assertNotNull(savedAsset);
        assertNotNull(savedAsset.getId());
        assertEquals("AST-101", savedAsset.getAssetCode());
        assertEquals("Dell Latitude Laptop", savedAsset.getAssetName());
    }

    @Test
    public void testGetAllAssetItems() {

        // ToDo Test Case 2
        // Verify fetching asset items returns
        // a non-null list
        List<AssetItemBean> list = assetItemService.getAllAssetItems();
        assertNotNull(list);
    }

    @Test
    public void testAddAndFetchAssetItems() {

        // ToDo Test Case 3
        // Verify end-to-end add and fetch flow
        AssetItemBean assetItemBean = new AssetItemBean();
        assetItemBean.setAssetCode("AST-102");
        assetItemBean.setAssetName("HP 24-inch Monitor");
        assetItemBean.setCategory("Display");
        assetItemBean.setAssignedTo("Sarah Connor");
        assetItemBean.setStatus("Available");

        AssetItemBean savedAsset = assetItemService.addAssetItem(assetItemBean);
        assertNotNull(savedAsset);

        List<AssetItemBean> list = assetItemService.getAllAssetItems();
        assertNotNull(list);
        assertTrue(list.size() > 0);
    }
}
